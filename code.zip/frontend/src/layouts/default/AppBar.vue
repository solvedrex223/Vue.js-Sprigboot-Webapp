<template>
  <div>
    <!--<v-toolbar
      dark
      prominent
      image="https://cdn.vuetifyjs.com/images/backgrounds/vbanner.jpg"
    >-->
    <v-toolbar
      dark
      prominent
      image="https://static.vecteezy.com/system/resources/thumbnails/002/437/377/small/horizontal-yellow-and-orange-grunge-texture-cement-or-concrete-wall-banner-blank-background-free-photo.jpg"
    >
      <!-- <v-app-bar-nav-icon style="color:white"></v-app-bar-nav-icon> -->

      <v-app-bar-title style="color:white">
        <v-icon icon="mdi-calculator"/>
        Proyecto Final de Arquitectura de Software
      </v-app-bar-title>

      <v-spacer></v-spacer>

      <v-btn icon style="color:white">
        <v-icon>mdi-export</v-icon>
      </v-btn>
    </v-toolbar>
  </div>
</template>

<!--<template>
  <v-app-bar flat>
    <v-app-bar-title>
      <v-icon icon="mdi-calculator"/>
      Proyecto Final de Taller de Formación Profesional
    </v-app-bar-title>
  </v-app-bar>
</template>-->

<script lang="ts" setup>
  //
</script>