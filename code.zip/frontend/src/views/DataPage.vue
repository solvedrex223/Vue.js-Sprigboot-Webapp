<template>
    <Suspense>
        <Data />
    </Suspense>
</template>
<script setup lang="ts">
import Data from '@/components/Data.vue';
</script>