/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type AllItems = Array<{
name?: string;
price?: number;
img?: string;
id?: number;
}>;
