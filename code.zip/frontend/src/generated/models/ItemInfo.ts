/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ItemInfo = {
    /**
     * the ID of the item.
     */
    id?: number;
    /**
     * the name of the item.
     */
    name?: string;
    /**
     * the price of the item.
     */
    price?: number;
};
