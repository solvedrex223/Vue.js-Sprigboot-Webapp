# Design
## Vue
Vue is a node.js framework that focuses on clean and reactive webpages.

## Vuetify
Vuetify is a html and css framework for vue that is built for template designed html pages.

## Typescript
Typescript is a programming language that supersets JavaScript made for static typing notations wich makes its syntaxis like a common programming language (C,Java) and helps with unsecure JavaScript calls.

## Cypress
Cypress is a testing programm made for node webpages that lets E2E testing

## Cucumber
Cucumber is a Gherkin impementation of its Domain Specific Language that lets writting tests as user stories and creating those tests in its intended applications.